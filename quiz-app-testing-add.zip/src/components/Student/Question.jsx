import React from 'react'

function Question({question,options}) {
  return (
    <div>Question</div>
  )
}

export default Question